<div class="amp-wp-meta amp-wp-byline">
	<?php coauthors(); ?>
</div>
